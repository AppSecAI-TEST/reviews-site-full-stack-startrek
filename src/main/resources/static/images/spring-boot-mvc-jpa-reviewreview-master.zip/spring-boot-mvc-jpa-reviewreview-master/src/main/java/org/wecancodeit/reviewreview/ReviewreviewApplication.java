package org.wecancodeit.reviewreview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewreviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewreviewApplication.class, args);
	}
}
